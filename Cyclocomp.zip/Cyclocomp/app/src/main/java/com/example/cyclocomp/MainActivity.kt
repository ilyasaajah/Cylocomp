package com.example.cyclocomp

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import java.io.File

// Jam dicari lewat awalan nama Bluetooth-nya (jam kamu: S47_08EA). Ubah kalau perlu.
const val WATCH_NAME_PREFIX = "S47"

@SuppressLint("MissingPermission")
@Suppress("OVERRIDE_DEPRECATION")
class MainActivity : AppCompatActivity(), LocationListener {
    private lateinit var map: MapView
    private lateinit var speedTv: TextView
    private lateinit var distTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var avgTv: TextView
    private lateinit var hrTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var rideBtn: Button
    private lateinit var watchBtn: Button
    private val track = Polyline()
    private val ui = Handler(Looper.getMainLooper())
    private var riding = false
    private var distM = 0.0
    private var movingS = 0
    private var curSpeed = 0f
    private var last: Location? = null
    private var link: WatchLink? = null
    private var gpsOn = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Configuration.getInstance().apply {
            load(this@MainActivity, getSharedPreferences("osm", 0))
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osm")
            osmdroidTileCache = File(cacheDir, "osm/t")
        }
        fun tv(size: Float, text: String) = TextView(this).apply {
            textSize = size; this.text = text; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        }
        speedTv = tv(64f, "0.0")
        distTv = tv(18f, "0.00 km"); timeTv = tv(18f, "00:00:00"); avgTv = tv(18f, "0.0 avg")
        hrTv = tv(28f, "HR --"); statusTv = tv(12f, "Siap")
        rideBtn = Button(this).apply { text = "Mulai"; setOnClickListener { toggleRide() } }
        watchBtn = Button(this).apply { text = "Sambung jam"; setOnClickListener { toggleWatch() } }
        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true)
            controller.setZoom(17.0)
            track.outlinePaint.color = Color.RED; track.outlinePaint.strokeWidth = 8f
            overlays.add(track)
        }
        val stats = LinearLayout(this).apply {
            listOf(distTv, timeTv, avgTv).forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        }
        val buttons = LinearLayout(this).apply {
            listOf(rideBtn, watchBtn).forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK)
            addView(speedTv, ViewGroup.LayoutParams(-1, -2))
            addView(tv(12f, "km/h"), ViewGroup.LayoutParams(-1, -2))
            addView(stats, ViewGroup.LayoutParams(-1, -2))
            addView(hrTv, ViewGroup.LayoutParams(-1, -2))
            addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(buttons, ViewGroup.LayoutParams(-1, -2))
            addView(statusTv, ViewGroup.LayoutParams(-1, -2))
        })
        if (granted()) startGps() else ActivityCompat.requestPermissions(this, needPerms(), 1)
    }

    private fun needPerms() =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun granted() = needPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (granted()) startGps() else status("Izin ditolak: lokasi/Bluetooth dibutuhkan")
    }

    private fun status(t: String) = runOnUiThread { statusTv.text = t }

    private fun startGps() {
        if (gpsOn) return
        gpsOn = true
        getSystemService(LocationManager::class.java)
            .requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        status("Menunggu sinyal GPS...")
    }

    private fun toggleRide() {
        riding = !riding
        rideBtn.text = if (riding) "Berhenti" else "Mulai"
        if (riding) {
            distM = 0.0; movingS = 0; last = null; track.setPoints(emptyList())
            ui.post(object : Runnable {
                override fun run() {
                    if (!riding) return
                    if (curSpeed > 0.8f) movingS++
                    refresh(); ui.postDelayed(this, 1000)
                }
            })
        }
    }

    private fun refresh() {
        distTv.text = "%.2f km".format(distM / 1000)
        timeTv.text = "%02d:%02d:%02d".format(movingS / 3600, movingS % 3600 / 60, movingS % 60)
        avgTv.text = "%.1f avg".format(if (movingS > 0) distM / movingS * 3.6 else 0.0)
    }

    override fun onLocationChanged(l: Location) {
        curSpeed = if (l.hasSpeed()) l.speed else 0f
        speedTv.text = "%.1f".format(curSpeed * 3.6f)
        val gp = GeoPoint(l.latitude, l.longitude)
        map.controller.animateTo(gp)
        if (riding && l.accuracy < 30f) {
            val p = last
            if (p == null) { last = l; track.addPoint(gp) }
            else if (p.distanceTo(l) > 2f) { distM += p.distanceTo(l); last = l; track.addPoint(gp) }
            map.invalidate()
        }
        status("GPS ok (±${l.accuracy.toInt()} m)")
    }

    override fun onStatusChanged(provider: String?, st: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { status("GPS mati, nyalakan di pengaturan") }

    private fun toggleWatch() {
        if (link != null) {
            link?.close(); link = null; watchBtn.text = "Sambung jam"; hrTv.text = "HR --"; return
        }
        if (!granted()) { ActivityCompat.requestPermissions(this, needPerms(), 1); return }
        val ad = getSystemService(BluetoothManager::class.java).adapter
        if (ad == null || !ad.isEnabled) { status("Nyalakan Bluetooth dulu"); return }
        val sc = ad.bluetoothLeScanner
        status("Mencari jam ($WATCH_NAME_PREFIX...) - putuskan InfoWear dulu")
        val cb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                val n = r.scanRecord?.deviceName ?: r.device.name ?: return
                if (!n.startsWith(WATCH_NAME_PREFIX)) return
                sc.stopScan(this)
                link = WatchLink(this@MainActivity, r.device,
                    { hr -> runOnUiThread { hrTv.text = "HR $hr bpm" } }, { m -> status(m) })
                runOnUiThread { watchBtn.text = "Putus jam" }
                link?.connect()
            }
        }
        sc.startScan(cb)
        ui.postDelayed({ sc.stopScan(cb); if (link == null) status("Jam tidak ketemu") }, 15000)
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { super.onPause(); map.onPause() }
    override fun onDestroy() {
        super.onDestroy()
        link?.close()
        getSystemService(LocationManager::class.java).removeUpdates(this)
    }
}
