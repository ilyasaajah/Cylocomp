package com.example.cyclocomp

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.UUID

/**
 * Protokol jam S47 (hasil baca log Bluetooth InfoWear):
 *  - Layanan 16186f00-..., karakteristik urut handle: [0] = kanal HP->jam, [1] = kanal jam->HP
 *  - Kirim pesan: tulis ANNOUNCE -> tunggu READY (notify) -> tulis frame (01 00 + protobuf) -> tunggu DONE
 *  - Terima pesan: jam notify ANNOUNCE -> HP tulis READY -> jam notify frame -> HP tulis DONE
 *  - Perintah 164 {12:{3:0}} = mulai data real-time, jam lalu kirim pesan 165; field 4 = detak jantung
 */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class WatchLink(
    private val ctx: Context,
    private val dev: BluetoothDevice,
    private val onHr: (Int) -> Unit,
    private val onStatus: (String) -> Unit
) : BluetoothGattCallback() {

    companion object {
        val SERVICE: UUID = UUID.fromString("16186f00-0000-1000-8000-00807f9b34fb")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00807f9b34fb")
        fun b(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }
        val ANNOUNCE = b(0, 0, 0, 0, 1, 0)
        val READY = b(0, 0, 1, 1, 0, 0)
        val DONE = b(0, 0, 1, 0, 0, 0)
        val HANDSHAKE = b(0x08, 0x00, 0x9a, 0x06, 0x09, 0x08, 0xf7, 0x01, 0x10, 0x0c, 0x18, 0x0c, 0x20, 0x00)
        val KEEPALIVE = b(0x08, 0x10)
        val HR_START = b(0x08, 0xa4, 0x01, 0x62, 0x02, 0x18, 0x00)
        val HR_STOP = b(0x08, 0xa4, 0x01, 0x62, 0x02, 0x18, 0x01)
    }

    private val h = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var ctrl: BluetoothGattCharacteristic? = null
    private var data: BluetoothGattCharacteristic? = null
    private val chars = ArrayList<BluetoothGattCharacteristic>()
    private var cccdIdx = 0
    private val raw = ArrayDeque<Pair<BluetoothGattCharacteristic, ByteArray>>()
    private var rawBusy = false
    private val msgs = ArrayDeque<ByteArray>()
    private var msgBusy = false
    private var cur: ByteArray? = null
    private var lastHr = 0L
    private var closed = false

    fun connect() {
        onStatus("Menyambung ke ${dev.name}...")
        gatt = dev.connectGatt(ctx, false, this, BluetoothDevice.TRANSPORT_LE)
    }

    fun close() {
        if (closed) return
        send(HR_STOP)
        h.postDelayed({ closed = true; gatt?.close() }, 800)
    }

    override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
        if (newState == BluetoothProfile.STATE_CONNECTED) g.requestMtu(247)
        else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            closed = true; g.close(); onStatus("Jam terputus")
        }
    }

    override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) { g.discoverServices() }

    override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
        h.post {
            val s = g.getService(SERVICE)
            if (s == null || s.characteristics.size < 2) { onStatus("Layanan jam tidak ditemukan"); return@post }
            chars.addAll(s.characteristics)
            ctrl = chars[0]; data = chars[1]
            chars.forEach { g.setCharacteristicNotification(it, true) }
            enableNext()
        }
    }

    private fun enableNext() {
        val g = gatt ?: return
        if (cccdIdx >= chars.size) { startSession(); return }
        val d = chars[cccdIdx++].getDescriptor(CCCD)
        if (d == null) { enableNext(); return }
        d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        g.writeDescriptor(d)
    }

    override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
        h.post { enableNext() }
    }

    private fun startSession() {
        onStatus("Tersambung, meminta detak jantung...")
        send(HANDSHAKE); send(KEEPALIVE); send(HR_START)
        lastHr = SystemClock.elapsedRealtime()
        h.postDelayed(object : Runnable {
            override fun run() {
                if (closed) return
                send(KEEPALIVE)
                if (SystemClock.elapsedRealtime() - lastHr > 20000) send(HR_START)
                h.postDelayed(this, 10000)
            }
        }, 10000)
    }

    // ---- kirim pesan (HP -> jam) ----
    private fun send(proto: ByteArray) { msgs.add(b(1, 0) + proto); pump() }

    private fun pump() {
        if (msgBusy || ctrl == null) return
        val m = msgs.removeFirstOrNull() ?: return
        msgBusy = true; cur = m
        write(ctrl!!, ANNOUNCE)
        h.postDelayed({ if (cur === m) { cur = null; msgBusy = false; pump() } }, 3000)
    }

    private fun write(c: BluetoothGattCharacteristic, v: ByteArray) { raw.add(c to v); nextRaw() }

    private fun nextRaw() {
        if (rawBusy) return
        val (c, v) = raw.removeFirstOrNull() ?: return
        rawBusy = true
        c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        c.value = v
        if (gatt?.writeCharacteristic(c) != true) {
            rawBusy = false; raw.addFirst(c to v); h.postDelayed({ nextRaw() }, 50)
        }
    }

    override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
        h.post { rawBusy = false; nextRaw() }
    }

    // ---- terima (jam -> HP) ----
    override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
        val v = c.value?.copyOf() ?: return
        val id = c.instanceId
        h.post {
            if (id == ctrl?.instanceId) {
                if (v.contentEquals(READY)) cur?.let { write(ctrl!!, it) }
                else if (v.contentEquals(DONE)) { msgBusy = false; cur = null; pump() }
            } else if (id == data?.instanceId) {
                if (v.contentEquals(ANNOUNCE)) write(data!!, READY)
                else if (v.size > 2 && v[0].toInt() == 1) {
                    handle(v.copyOfRange(2, v.size)); write(data!!, DONE)
                }
            }
        }
    }

    private fun handle(body: ByteArray) {
        val m = pb(body)
        if (m[1] != 165L) return
        val a = (m[12] as? ByteArray)?.let { pb(it) }
        val s = (a?.get(4) as? ByteArray)?.let { pb(it) }
        val hr = (s?.get(4) as? Long)?.toInt() ?: return
        if (hr in 30..220) { lastHr = SystemClock.elapsedRealtime(); onHr(hr) }
    }

    /** Pembaca protobuf minimal: field -> Long (varint) atau ByteArray (sub-pesan). */
    private fun pb(b: ByteArray): Map<Int, Any> {
        val m = HashMap<Int, Any>(); var p = 0
        fun vi(): Long {
            var r = 0L; var sh = 0
            while (p < b.size) { val x = b[p++].toInt() and 0xff; r = r or ((x and 0x7f).toLong() shl sh); sh += 7; if (x < 0x80) break }
            return r
        }
        while (p < b.size) {
            val k = vi().toInt(); val f = k shr 3
            when (k and 7) {
                0 -> m[f] = vi()
                2 -> { val l = vi().toInt(); if (l < 0 || p + l > b.size) break; m[f] = b.copyOfRange(p, p + l); p += l }
                1 -> p += 8
                5 -> p += 4
                else -> break
            }
        }
        return m
    }
}
